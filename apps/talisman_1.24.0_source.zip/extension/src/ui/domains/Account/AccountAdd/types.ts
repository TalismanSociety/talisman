export type AccountAddPageProps = { onSuccess: (address: string) => void }
