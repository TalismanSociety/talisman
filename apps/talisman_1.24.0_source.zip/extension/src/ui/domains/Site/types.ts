export type SiteConnectionStatus = "connected" | "disconnected" | "disabled"
