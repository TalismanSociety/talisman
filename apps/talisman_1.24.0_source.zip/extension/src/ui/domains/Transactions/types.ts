export type TxReplaceType = "speed-up" | "cancel"
