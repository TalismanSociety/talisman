import { useGlobalOpenClose } from "@talisman/hooks/useGlobalOpenClose"

export const useBuyTokensModal = () => useGlobalOpenClose("buyTokensModal")
