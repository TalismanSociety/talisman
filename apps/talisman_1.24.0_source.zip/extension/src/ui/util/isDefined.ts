export const isDefined = <T>(arg: T | null | undefined): arg is T => !!arg
