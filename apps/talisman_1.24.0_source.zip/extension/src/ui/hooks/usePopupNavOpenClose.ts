import { useGlobalOpenClose } from "@talisman/hooks/useGlobalOpenClose"

export const usePopupNavOpenClose = () => useGlobalOpenClose("popupNav")
