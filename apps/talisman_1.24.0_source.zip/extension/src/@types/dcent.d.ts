declare module "dcent-web-connector"
