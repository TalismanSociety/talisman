import "@common/enableLogsInDevelopment"
import "@common/i18nConfig"

import { renderTalisman } from "@ui"
import Dashboard from "@ui/apps/dashboard"

renderTalisman(<Dashboard />)
