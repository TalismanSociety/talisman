import "@common/enableLogsInDevelopment"
import "@common/i18nConfig"

import { renderTalisman } from "@ui"
import Onboarding from "@ui/apps/onboard"

renderTalisman(<Onboarding />)
