import "@common/enableLogsInDevelopment"
import "@common/i18nConfig"
import "@extension/core/background"
