module.exports = {
  presets: ["@talismn"],
}
